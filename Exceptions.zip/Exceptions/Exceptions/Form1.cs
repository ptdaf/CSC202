﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Functions
{
    public partial class Form1 : Form
    {
        private string Firstname;
        private string Middlename;
        private string Lastname;


        public Form1()
        {
            InitializeComponent();
        }

        // Helper method to check if a string contains numbers
        private bool ContainsNumbers(string input)
        {
            return input.Any(char.IsDigit);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void FirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                // Safely capture the text and trim whitespace
                Firstname = FirstName.Text?.Trim();

                // Check for the Enter key press
                if (e.KeyChar == (char)Keys.Enter)
                {
                    if (string.IsNullOrEmpty(Firstname))
                    {
                        throw new ArgumentException("First name cannot be empty.");
                    }
                    else if (ContainsNumbers(Firstname))
                    {
                        throw new InvalidOperationException("First name cannot contain numbers.");
                    }
                    FirstLbl.Text = Firstname; // Moved inside the validation success block
                }
            }
            catch (ArgumentException ex)
            {
                // Handle empty input case
                MessageBox.Show($"Error: {ex.Message}");
            }
            catch (InvalidOperationException ex)
            {
                // Handle numeric input case
                MessageBox.Show($"Error: {ex.Message}");

                FirstName.Text = string.Empty;
                FirstLbl.Text = string.Empty;
            }
            catch (Exception ex)
            {
                // Handle any unexpected errors
                MessageBox.Show($"An unexpected error occurred: {ex.Message}");
            }
        }
        public void MiddleName_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                // Safely capture the text and trim whitespace
                Middlename = MiddleName.Text?.Trim();

                // Check for the Enter key press
                if (e.KeyChar == (char)Keys.Enter)
                {
                    // Validate that the input does not contain numbers
                    if (string.IsNullOrEmpty(Middlename))
                    {
                        throw new ArgumentException("Middle name cannot be empty.");
                    }
                    else if (ContainsNumbers(Middlename))
                    {
                        throw new InvalidOperationException("Middle name cannot contain numbers.");
                    }

                    // Update the label or control
                    MiddleLbl.Text = Middlename;
                }
            }
            catch (ArgumentException ex)
            {
                // Handle empty input case
                MessageBox.Show($"Error: {ex.Message}");
            }
            catch (InvalidOperationException ex)
            {
                // Handle numeric input case
                MessageBox.Show($"Error: {ex.Message}");

                MiddleName.Text = string.Empty;
                MiddleLbl.Text = string.Empty;
            }
            catch (Exception ex)
            {
                // Handle any unexpected errors
                MessageBox.Show($"An unexpected error occurred: {ex.Message}");
            }
        }

        public void LastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                // Safely capture the text and trim whitespace
                Lastname = LastName.Text?.Trim();

                // Check for the Enter key press
                if (e.KeyChar == (char)Keys.Enter)
                {
                    // Validate that the input does not contain numbers
                    if (string.IsNullOrEmpty(Lastname))
                    {
                        throw new ArgumentException("Last name cannot be empty.");
                    }
                    else if (ContainsNumbers(Lastname))
                    {
                        throw new InvalidOperationException("Last name cannot contain numbers.");
                    }

                    // Update the label or control
                    LastLbl.Text = Lastname;
                }
            }
            catch (ArgumentException ex)
            {
                // Handle empty input case
                MessageBox.Show($"Error: {ex.Message}");
            }
            catch (InvalidOperationException ex)
            {
                // Handle numeric input case
                MessageBox.Show($"Error: {ex.Message}");

                LastName.Text = string.Empty;
                LastLbl.Text = string.Empty;

            }
            catch (Exception ex)
            {
                // Handle any unexpected errors
                MessageBox.Show($"An unexpected error occurred: {ex.Message}");
            }
        }

        public void SubmitButt_Click(object sender, EventArgs e)
        {
            try
            {
                // Trim input values and validate
                string trimmedFirstLbl = Firstname?.Trim() ?? string.Empty;
                string trimmedMiddleLbl = Middlename?.Trim() ?? string.Empty;
                string trimmedLastLbl = Lastname?.Trim() ?? string.Empty;

                // Check if the essential fields are filled in
                if (string.IsNullOrEmpty(trimmedFirstLbl) || string.IsNullOrEmpty(trimmedLastLbl))
                {
                    MessageBox.Show("Please enter both your first name and last name.");
                    return;
                }

                // Concatenate full name
                string Fullname = $"{trimmedFirstLbl} {trimmedMiddleLbl} {trimmedLastLbl}".Trim();

                // Display the full name
                MessageBox.Show("Your full name is: " + Fullname);
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                MessageBox.Show("An unexpected error occurred: " + ex.Message);
            }
        }
    }
}