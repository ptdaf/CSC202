﻿namespace Functions
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FirstLbl = new System.Windows.Forms.Label();
            this.LastLbl = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.TextBox();
            this.MiddleName = new System.Windows.Forms.TextBox();
            this.MiddleLbl = new System.Windows.Forms.Label();
            this.SubmitButt = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // FirstLbl
            // 
            this.FirstLbl.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FirstLbl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FirstLbl.Location = new System.Drawing.Point(67, 167);
            this.FirstLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.FirstLbl.Name = "FirstLbl";
            this.FirstLbl.Size = new System.Drawing.Size(75, 19);
            this.FirstLbl.TabIndex = 2;
            this.FirstLbl.Text = " ";
            // 
            // LastLbl
            // 
            this.LastLbl.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LastLbl.Location = new System.Drawing.Point(457, 167);
            this.LastLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LastLbl.Name = "LastLbl";
            this.LastLbl.Size = new System.Drawing.Size(75, 19);
            this.LastLbl.TabIndex = 3;
            this.LastLbl.Text = " ";
            // 
            // FirstName
            // 
            this.FirstName.Location = new System.Drawing.Point(67, 225);
            this.FirstName.Margin = new System.Windows.Forms.Padding(2);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(76, 20);
            this.FirstName.TabIndex = 4;
            this.FirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FirstName_KeyPress);
            // 
            // LastName
            // 
            this.LastName.Location = new System.Drawing.Point(457, 225);
            this.LastName.Margin = new System.Windows.Forms.Padding(2);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(76, 20);
            this.LastName.TabIndex = 5;
            this.LastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.LastName_KeyPress);
            // 
            // MiddleName
            // 
            this.MiddleName.Location = new System.Drawing.Point(269, 226);
            this.MiddleName.Margin = new System.Windows.Forms.Padding(2);
            this.MiddleName.Name = "MiddleName";
            this.MiddleName.Size = new System.Drawing.Size(76, 20);
            this.MiddleName.TabIndex = 8;
            this.MiddleName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MiddleName_KeyPress);
            // 
            // MiddleLbl
            // 
            this.MiddleLbl.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MiddleLbl.Location = new System.Drawing.Point(269, 167);
            this.MiddleLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MiddleLbl.Name = "MiddleLbl";
            this.MiddleLbl.Size = new System.Drawing.Size(75, 19);
            this.MiddleLbl.TabIndex = 7;
            this.MiddleLbl.Text = " ";
            // 
            // SubmitButt
            // 
            this.SubmitButt.Location = new System.Drawing.Point(279, 324);
            this.SubmitButt.Margin = new System.Windows.Forms.Padding(2);
            this.SubmitButt.Name = "SubmitButt";
            this.SubmitButt.Size = new System.Drawing.Size(56, 19);
            this.SubmitButt.TabIndex = 6;
            this.SubmitButt.Text = "Submit";
            this.SubmitButt.UseVisualStyleBackColor = true;
            this.SubmitButt.Click += new System.EventHandler(this.SubmitButt_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 103);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(269, 102);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Middle Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(459, 102);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Last Name";
            // 
            // label
            // 
            this.label.BackColor = System.Drawing.Color.LightGray;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(134, 32);
            this.label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(329, 26);
            this.label.TabIndex = 12;
            this.label.Text = "Press \'Enter\' before moving on to next text box.\r\n";
            this.label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.label);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MiddleName);
            this.Controls.Add(this.MiddleLbl);
            this.Controls.Add(this.SubmitButt);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.LastLbl);
            this.Controls.Add(this.FirstLbl);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label FirstLbl;
        private System.Windows.Forms.Label LastLbl;
        private System.Windows.Forms.TextBox FirstName;
        private System.Windows.Forms.TextBox LastName;
        private System.Windows.Forms.TextBox MiddleName;
        private System.Windows.Forms.Label MiddleLbl;
        private System.Windows.Forms.Button SubmitButt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label;
    }
}

