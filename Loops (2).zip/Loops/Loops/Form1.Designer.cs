﻿namespace Loops
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Kill3 = new System.Windows.Forms.TextBox();
            this.Kill1 = new System.Windows.Forms.TextBox();
            this.Kill2 = new System.Windows.Forms.TextBox();
            this.Kill4 = new System.Windows.Forms.TextBox();
            this.Kill5 = new System.Windows.Forms.TextBox();
            this.Death1 = new System.Windows.Forms.TextBox();
            this.Death2 = new System.Windows.Forms.TextBox();
            this.Death3 = new System.Windows.Forms.TextBox();
            this.Death4 = new System.Windows.Forms.TextBox();
            this.Death5 = new System.Windows.Forms.TextBox();
            this.KD1 = new System.Windows.Forms.Label();
            this.KD2 = new System.Windows.Forms.Label();
            this.KD3 = new System.Windows.Forms.Label();
            this.KD4 = new System.Windows.Forms.Label();
            this.KD5 = new System.Windows.Forms.Label();
            this.Player1 = new System.Windows.Forms.Label();
            this.Player2 = new System.Windows.Forms.Label();
            this.Player3 = new System.Windows.Forms.Label();
            this.Player4 = new System.Windows.Forms.Label();
            this.Player5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.KillLbl = new System.Windows.Forms.Label();
            this.DeathLbl = new System.Windows.Forms.Label();
            this.AvgTeamKills = new System.Windows.Forms.Label();
            this.AvgTeamDeaths = new System.Windows.Forms.Label();
            this.AvgKillLabel = new System.Windows.Forms.Label();
            this.AvgDeathLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33555F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33223F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33223F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tableLayoutPanel1.Controls.Add(this.Kill3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.Kill1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.Kill2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.Kill4, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.Kill5, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.Death1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.Death2, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.Death3, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.Death4, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.Death5, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.KD1, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.KD2, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.KD3, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.KD4, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.KD5, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.Player1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.Player2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.Player3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.Player4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.Player5, 0, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(192, 143);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(338, 138);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // Kill3
            // 
            this.Kill3.Location = new System.Drawing.Point(93, 57);
            this.Kill3.Name = "Kill3";
            this.Kill3.Size = new System.Drawing.Size(83, 20);
            this.Kill3.TabIndex = 1;
            // 
            // Kill1
            // 
            this.Kill1.Location = new System.Drawing.Point(93, 3);
            this.Kill1.Name = "Kill1";
            this.Kill1.Size = new System.Drawing.Size(83, 20);
            this.Kill1.TabIndex = 2;
            // 
            // Kill2
            // 
            this.Kill2.Location = new System.Drawing.Point(93, 30);
            this.Kill2.Name = "Kill2";
            this.Kill2.Size = new System.Drawing.Size(83, 20);
            this.Kill2.TabIndex = 3;
            // 
            // Kill4
            // 
            this.Kill4.Location = new System.Drawing.Point(93, 84);
            this.Kill4.Name = "Kill4";
            this.Kill4.Size = new System.Drawing.Size(83, 20);
            this.Kill4.TabIndex = 7;
            // 
            // Kill5
            // 
            this.Kill5.Location = new System.Drawing.Point(93, 111);
            this.Kill5.Name = "Kill5";
            this.Kill5.Size = new System.Drawing.Size(83, 20);
            this.Kill5.TabIndex = 8;
            // 
            // Death1
            // 
            this.Death1.Location = new System.Drawing.Point(182, 3);
            this.Death1.Name = "Death1";
            this.Death1.Size = new System.Drawing.Size(83, 20);
            this.Death1.TabIndex = 9;
            // 
            // Death2
            // 
            this.Death2.Location = new System.Drawing.Point(182, 30);
            this.Death2.Name = "Death2";
            this.Death2.Size = new System.Drawing.Size(83, 20);
            this.Death2.TabIndex = 10;
            // 
            // Death3
            // 
            this.Death3.Location = new System.Drawing.Point(182, 57);
            this.Death3.Name = "Death3";
            this.Death3.Size = new System.Drawing.Size(83, 20);
            this.Death3.TabIndex = 11;
            // 
            // Death4
            // 
            this.Death4.Location = new System.Drawing.Point(182, 84);
            this.Death4.Name = "Death4";
            this.Death4.Size = new System.Drawing.Size(83, 20);
            this.Death4.TabIndex = 12;
            // 
            // Death5
            // 
            this.Death5.Location = new System.Drawing.Point(182, 111);
            this.Death5.Name = "Death5";
            this.Death5.Size = new System.Drawing.Size(83, 20);
            this.Death5.TabIndex = 13;
            // 
            // KD1
            // 
            this.KD1.AutoSize = true;
            this.KD1.Location = new System.Drawing.Point(271, 0);
            this.KD1.Name = "KD1";
            this.KD1.Size = new System.Drawing.Size(29, 13);
            this.KD1.TabIndex = 14;
            this.KD1.Text = "KDA";
            // 
            // KD2
            // 
            this.KD2.AutoSize = true;
            this.KD2.Location = new System.Drawing.Point(271, 27);
            this.KD2.Name = "KD2";
            this.KD2.Size = new System.Drawing.Size(29, 13);
            this.KD2.TabIndex = 15;
            this.KD2.Text = "KDA";
            // 
            // KD3
            // 
            this.KD3.AutoSize = true;
            this.KD3.Location = new System.Drawing.Point(271, 54);
            this.KD3.Name = "KD3";
            this.KD3.Size = new System.Drawing.Size(29, 13);
            this.KD3.TabIndex = 16;
            this.KD3.Text = "KDA";
            // 
            // KD4
            // 
            this.KD4.AutoSize = true;
            this.KD4.Location = new System.Drawing.Point(271, 81);
            this.KD4.Name = "KD4";
            this.KD4.Size = new System.Drawing.Size(29, 13);
            this.KD4.TabIndex = 17;
            this.KD4.Text = "KDA";
            // 
            // KD5
            // 
            this.KD5.AutoSize = true;
            this.KD5.Location = new System.Drawing.Point(271, 108);
            this.KD5.Name = "KD5";
            this.KD5.Size = new System.Drawing.Size(29, 13);
            this.KD5.TabIndex = 18;
            this.KD5.Text = "KDA";
            // 
            // Player1
            // 
            this.Player1.AutoSize = true;
            this.Player1.BackColor = System.Drawing.SystemColors.Control;
            this.Player1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Player1.Location = new System.Drawing.Point(3, 0);
            this.Player1.Name = "Player1";
            this.Player1.Size = new System.Drawing.Size(47, 15);
            this.Player1.TabIndex = 19;
            this.Player1.Text = "Player 1";
            // 
            // Player2
            // 
            this.Player2.AutoSize = true;
            this.Player2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Player2.Location = new System.Drawing.Point(3, 27);
            this.Player2.Name = "Player2";
            this.Player2.Size = new System.Drawing.Size(47, 15);
            this.Player2.TabIndex = 20;
            this.Player2.Text = "Player 2";
            // 
            // Player3
            // 
            this.Player3.AutoSize = true;
            this.Player3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Player3.Location = new System.Drawing.Point(3, 54);
            this.Player3.Name = "Player3";
            this.Player3.Size = new System.Drawing.Size(47, 15);
            this.Player3.TabIndex = 21;
            this.Player3.Text = "Player 3";
            // 
            // Player4
            // 
            this.Player4.AutoSize = true;
            this.Player4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Player4.Location = new System.Drawing.Point(3, 81);
            this.Player4.Name = "Player4";
            this.Player4.Size = new System.Drawing.Size(47, 15);
            this.Player4.TabIndex = 22;
            this.Player4.Text = "Player 4";
            // 
            // Player5
            // 
            this.Player5.AutoSize = true;
            this.Player5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Player5.Location = new System.Drawing.Point(3, 108);
            this.Player5.Name = "Player5";
            this.Player5.Size = new System.Drawing.Size(47, 15);
            this.Player5.TabIndex = 23;
            this.Player5.Text = "Player 5";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(338, 368);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(76, 44);
            this.button1.TabIndex = 1;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // KillLbl
            // 
            this.KillLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.KillLbl.AutoSize = true;
            this.KillLbl.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.KillLbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.KillLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KillLbl.Location = new System.Drawing.Point(281, 122);
            this.KillLbl.Name = "KillLbl";
            this.KillLbl.Size = new System.Drawing.Size(36, 20);
            this.KillLbl.TabIndex = 2;
            this.KillLbl.Text = "Kills";
            // 
            // DeathLbl
            // 
            this.DeathLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DeathLbl.AutoSize = true;
            this.DeathLbl.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.DeathLbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeathLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeathLbl.Location = new System.Drawing.Point(373, 120);
            this.DeathLbl.Name = "DeathLbl";
            this.DeathLbl.Size = new System.Drawing.Size(61, 20);
            this.DeathLbl.TabIndex = 3;
            this.DeathLbl.Text = "Deaths";
            // 
            // AvgTeamKills
            // 
            this.AvgTeamKills.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AvgTeamKills.AutoSize = true;
            this.AvgTeamKills.Location = new System.Drawing.Point(282, 328);
            this.AvgTeamKills.Name = "AvgTeamKills";
            this.AvgTeamKills.Size = new System.Drawing.Size(55, 13);
            this.AvgTeamKills.TabIndex = 4;
            this.AvgTeamKills.Text = "Team Kills";
            // 
            // AvgTeamDeaths
            // 
            this.AvgTeamDeaths.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AvgTeamDeaths.AutoSize = true;
            this.AvgTeamDeaths.Location = new System.Drawing.Point(379, 328);
            this.AvgTeamDeaths.Name = "AvgTeamDeaths";
            this.AvgTeamDeaths.Size = new System.Drawing.Size(71, 13);
            this.AvgTeamDeaths.TabIndex = 5;
            this.AvgTeamDeaths.Text = "Team Deaths";
            // 
            // AvgKillLabel
            // 
            this.AvgKillLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AvgKillLabel.AutoSize = true;
            this.AvgKillLabel.Location = new System.Drawing.Point(270, 299);
            this.AvgKillLabel.Name = "AvgKillLabel";
            this.AvgKillLabel.Size = new System.Drawing.Size(98, 13);
            this.AvgKillLabel.TabIndex = 6;
            this.AvgKillLabel.Text = "Average Team Kills";
            // 
            // AvgDeathLbl
            // 
            this.AvgDeathLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AvgDeathLbl.AutoSize = true;
            this.AvgDeathLbl.Location = new System.Drawing.Point(374, 299);
            this.AvgDeathLbl.Name = "AvgDeathLbl";
            this.AvgDeathLbl.Size = new System.Drawing.Size(114, 13);
            this.AvgDeathLbl.TabIndex = 7;
            this.AvgDeathLbl.Text = "Average Team Deaths";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(120, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(451, 62);
            this.label1.TabIndex = 8;
            this.label1.Text = "Type In Your Team\'s Match Results \r\nand Calculate Your Success";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(729, 439);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AvgDeathLbl);
            this.Controls.Add(this.AvgKillLabel);
            this.Controls.Add(this.AvgTeamDeaths);
            this.Controls.Add(this.AvgTeamKills);
            this.Controls.Add(this.DeathLbl);
            this.Controls.Add(this.KillLbl);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox Kill3;
        private System.Windows.Forms.TextBox Kill1;
        private System.Windows.Forms.TextBox Kill2;
        private System.Windows.Forms.TextBox Kill4;
        private System.Windows.Forms.TextBox Kill5;
        private System.Windows.Forms.TextBox Death1;
        private System.Windows.Forms.TextBox Death2;
        private System.Windows.Forms.TextBox Death3;
        private System.Windows.Forms.TextBox Death4;
        private System.Windows.Forms.TextBox Death5;
        private System.Windows.Forms.Label KD1;
        private System.Windows.Forms.Label KD2;
        private System.Windows.Forms.Label KD3;
        private System.Windows.Forms.Label KD4;
        private System.Windows.Forms.Label KD5;
        private System.Windows.Forms.Label Player1;
        private System.Windows.Forms.Label Player2;
        private System.Windows.Forms.Label Player3;
        private System.Windows.Forms.Label Player4;
        private System.Windows.Forms.Label Player5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label KillLbl;
        private System.Windows.Forms.Label DeathLbl;
        private System.Windows.Forms.Label AvgTeamKills;
        private System.Windows.Forms.Label AvgTeamDeaths;
        private System.Windows.Forms.Label AvgKillLabel;
        private System.Windows.Forms.Label AvgDeathLbl;
        private System.Windows.Forms.Label label1;
    }
}

