﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loops
{
    public partial class Form1 : Form
    {
        //creates array
        List <int> Kills = new List<int>();
        List <int> Deaths = new List<int>();

        public Form1()
        {
            InitializeComponent();

        }   

        //creates function to convert variables
        public string Average(string kill, string death)
        {
            int intK1 = 0;
            int intD1 = 0;
            try
            {
                intK1 = Int32.Parse(kill);
                Console.WriteLine(kill);

                intD1 = Int32.Parse(death);
                Console.WriteLine(death);

                Kills.Add(intK1);
                Deaths.Add(intD1);

            }
            catch (FormatException)
            {
               // Console.WriteLine($"Unable to Parse")k1.ToString();
            }
            //calculate average
            return ((float)intK1 / (float)intD1).ToString("F2");

        }

        //display variables on Table
        private void button1_Click(object sender, EventArgs e)
        {
            //function to Average each player's KD
            KD1.Text = Average(Kill1.Text, Death1.Text);
            KD2.Text = Average(Kill2.Text, Death2.Text);
            KD3.Text = Average(Kill3.Text, Death3.Text);
            KD4.Text = Average(Kill4.Text, Death4.Text);
            KD5.Text = Average(Kill5.Text, Death5.Text);

            int totalKills = 0;
            int totalDeaths = 0;

            //kill array loop
             for (int i = 0; i < Kills.Count; i++)
            {
                totalKills += Kills[i];
            }

                AvgTeamKills.Text = ((float)totalKills / (float)Kills.Count).ToString("F2");

            //death array loop
            for (int i = 0; i < Deaths.Count; i++)
            {
                totalDeaths += Deaths[i];
            }

                AvgTeamDeaths.Text = ((float)totalDeaths / (float)Deaths.Count).ToString("F2");

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}