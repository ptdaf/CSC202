﻿namespace Conditionals
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TitleLabel = new System.Windows.Forms.Label();
            this.UserInput_txt = new System.Windows.Forms.TextBox();
            this.Button = new System.Windows.Forms.Button();
            this.NumGen_lbl = new System.Windows.Forms.Label();
            this.red_btn = new System.Windows.Forms.Button();
            this.blue_btn = new System.Windows.Forms.Button();
            this.green_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TitleLabel
            // 
            this.TitleLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.BackColor = System.Drawing.Color.Transparent;
            this.TitleLabel.ForeColor = System.Drawing.Color.Black;
            this.TitleLabel.Location = new System.Drawing.Point(302, 71);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(167, 13);
            this.TitleLabel.TabIndex = 0;
            this.TitleLabel.Text = "Pick A Number between 1 and 10";
            this.TitleLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // UserInput_txt
            // 
            this.UserInput_txt.Location = new System.Drawing.Point(337, 219);
            this.UserInput_txt.MaxLength = 2;
            this.UserInput_txt.Name = "UserInput_txt";
            this.UserInput_txt.Size = new System.Drawing.Size(105, 20);
            this.UserInput_txt.TabIndex = 1;
            // 
            // Button
            // 
            this.Button.BackColor = System.Drawing.SystemColors.Control;
            this.Button.Location = new System.Drawing.Point(56, 104);
            this.Button.Name = "Button";
            this.Button.Size = new System.Drawing.Size(170, 94);
            this.Button.TabIndex = 3;
            this.Button.Text = "Enter Answer";
            this.Button.UseVisualStyleBackColor = false;
            this.Button.Click += new System.EventHandler(this.Button_Click);
            // 
            // NumGen_lbl
            // 
            this.NumGen_lbl.AutoSize = true;
            this.NumGen_lbl.Location = new System.Drawing.Point(345, 145);
            this.NumGen_lbl.Name = "NumGen_lbl";
            this.NumGen_lbl.Size = new System.Drawing.Size(87, 13);
            this.NumGen_lbl.TabIndex = 4;
            this.NumGen_lbl.Text = "Random Number";
            this.NumGen_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // red_btn
            // 
            this.red_btn.Location = new System.Drawing.Point(632, 104);
            this.red_btn.Name = "red_btn";
            this.red_btn.Size = new System.Drawing.Size(75, 23);
            this.red_btn.TabIndex = 5;
            this.red_btn.Text = "red";
            this.red_btn.UseVisualStyleBackColor = true;
            this.red_btn.Click += new System.EventHandler(this.red_btn_Click);
            // 
            // blue_btn
            // 
            this.blue_btn.Location = new System.Drawing.Point(632, 140);
            this.blue_btn.Name = "blue_btn";
            this.blue_btn.Size = new System.Drawing.Size(75, 23);
            this.blue_btn.TabIndex = 6;
            this.blue_btn.Text = "blue";
            this.blue_btn.UseVisualStyleBackColor = true;
            this.blue_btn.Click += new System.EventHandler(this.blue_btn_Click);
            // 
            // green_btn
            // 
            this.green_btn.Location = new System.Drawing.Point(632, 175);
            this.green_btn.Name = "green_btn";
            this.green_btn.Size = new System.Drawing.Size(75, 23);
            this.green_btn.TabIndex = 7;
            this.green_btn.Text = "green";
            this.green_btn.UseVisualStyleBackColor = true;
            this.green_btn.Click += new System.EventHandler(this.green_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.green_btn);
            this.Controls.Add(this.blue_btn);
            this.Controls.Add(this.red_btn);
            this.Controls.Add(this.NumGen_lbl);
            this.Controls.Add(this.Button);
            this.Controls.Add(this.UserInput_txt);
            this.Controls.Add(this.TitleLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.TextBox UserInput_txt;
        private System.Windows.Forms.Button Button;
        private System.Windows.Forms.Label NumGen_lbl;
        private System.Windows.Forms.Button red_btn;
        private System.Windows.Forms.Button blue_btn;
        private System.Windows.Forms.Button green_btn;
    }
}

