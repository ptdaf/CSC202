﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Conditionals
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int num = rnd.Next(10);  //creates a number between 0 and 10
            NumGen_lbl.Text = Convert.ToString(num); 

            string userI = UserInput_txt.Text; //takes input from UserInput textbox

            if (num.ToString() == userI) //condition compares random number to UserInput
            {
                MessageBox.Show("You guessed the right number!");
            }
            else { MessageBox.Show("You guessed wrong"); }

            //clears text box after message box
            UserInput_txt.Clear();
        }

            //changes background color
        private void red_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
        }

        private void blue_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
        }

        private void green_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Green;
        }
    }
}
