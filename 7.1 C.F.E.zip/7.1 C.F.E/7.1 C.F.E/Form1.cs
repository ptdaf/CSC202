﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _7._1_C.F.E
{
    public partial class Form1 : Form,  INotifyPropertyChanged
    {

        // value allowing change
        private int _distGuess;
        public int distGuess
        {
            get { return _distGuess; }
            set
            {
                 // 'Property Binding' the Label to the Variable
                _distGuess = value;
                OnPropertyChanged("distGuess");
            }
        }

         // Property Binding function
        protected virtual void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }          
        }

        public Form1()
        {
            InitializeComponent();

             // makes Property Binding True
            scrollValue.DataBindings.Add(new Binding("Text", this, "distGuess"));
        }

         // allows Scroll Bar value to be used
        private void scrollDistance(object sender, EventArgs e)
        {
           distGuess = hScrollBar1.Value;
        }

        // Property Change event
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        // button click submits Guess and Difference of Guess and Renerated Number
        private void button1_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            // int dist = 100; // uncomment to test "Hit"
            int dist = rnd.Next(501); // generates a number between 0 and 500
            int diff = dist - distGuess; // developes the difference of user's Guess and the Random Number

            if (dist == distGuess)
            {
                MessageBox.Show("You Hit!");
            }
            else
            {
                MessageBox.Show("You missed by " + diff + "ft!");
            }
        }
    }
}
