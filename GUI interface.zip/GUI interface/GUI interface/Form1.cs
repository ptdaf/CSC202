﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_interface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
            // creates integer for time left
        int timeleft = 5;

        private void button2_Click(object sender, EventArgs e)
        {
                //opens Form2 Window
            Form2 f2 = new Form2();
            f2.ShowDialog();

        }

        private void button1_Click(object sender, EventArgs e)
        {
                //creates message box with message
            MessageBox.Show("This is a message box");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
                //starts timer
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
                /*if timer is more than 0 seconds 
                 then label box is updated with remaining seconds
                 until 0 is reached*/

            if(timeleft > 0)
            {
                timeleft = timeleft - 1;
                timerlabel.Text = timeleft + " seconds";
            }
            else
            {
                timer1.Stop();
                timerlabel.Text = "your time is up";
                Close();
            }
        }

        private void timerLabel_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
