﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Functions
{
    public partial class Form1 : Form
    {
        private string Firstname;
        private string Middlename;
        private string Lastname;


        public Form1()
        {
            InitializeComponent();

        }

 
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void FirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            Firstname = FirstName.Text;

            if (e.KeyChar == (char)13)
            {
                First.Text = Firstname;
            }
        }

        public void MiddleName_KeyPress(object sender, KeyPressEventArgs e)
        {
            Middlename = MiddleName.Text;

            if (e.KeyChar == (char)13)
            {
                Middle.Text = Middlename;
            }
        }

        public void LastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            Lastname = LastName.Text;

            if (e.KeyChar == (char)13)
            {
                Last.Text = Lastname;
            }
        }

        public void SubmitButt_Click(object sender, EventArgs e)
        {
            string Fullname = Firstname + " " + Middlename + " " + Lastname;

            MessageBox.Show("Your full name is: " + Fullname);
        }
    }
}