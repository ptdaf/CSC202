﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Variables
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //number checking boolean output
            //userinput to string
            string userInput = UserGuess.Text;

            if (typeCheckInt(userInput))
            {
                MessageBox.Show("Your input '" + UserGuess.Text + "' is a number");
            }
            else
            {
                MessageBox.Show("Your input '" + UserGuess.Text + "' is not number");
            }

            //clears text box after message box
            UserGuess.Clear();
        }

        //number checking boolean
        private bool typeCheckInt(string input)

            //number checker
        {
            int number = 0;
            return int.TryParse(input, out number);
        }
    }
}
