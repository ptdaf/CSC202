﻿namespace Functions
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.First = new System.Windows.Forms.Label();
            this.Last = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.TextBox();
            this.MiddleName = new System.Windows.Forms.TextBox();
            this.Middle = new System.Windows.Forms.Label();
            this.SubmitButt = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // First
            // 
            this.First.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.First.ForeColor = System.Drawing.SystemColors.ControlText;
            this.First.Location = new System.Drawing.Point(89, 206);
            this.First.Name = "First";
            this.First.Size = new System.Drawing.Size(100, 23);
            this.First.TabIndex = 2;
            this.First.Text = " ";
            // 
            // Last
            // 
            this.Last.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Last.Location = new System.Drawing.Point(609, 205);
            this.Last.Name = "Last";
            this.Last.Size = new System.Drawing.Size(100, 23);
            this.Last.TabIndex = 3;
            this.Last.Text = " ";
            // 
            // FirstName
            // 
            this.FirstName.Location = new System.Drawing.Point(89, 277);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(100, 22);
            this.FirstName.TabIndex = 4;
            this.FirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FirstName_KeyPress);
            // 
            // LastName
            // 
            this.LastName.Location = new System.Drawing.Point(609, 277);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(100, 22);
            this.LastName.TabIndex = 5;
            this.LastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.LastName_KeyPress);
            // 
            // MiddleName
            // 
            this.MiddleName.Location = new System.Drawing.Point(359, 278);
            this.MiddleName.Name = "MiddleName";
            this.MiddleName.Size = new System.Drawing.Size(100, 22);
            this.MiddleName.TabIndex = 8;
            this.MiddleName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MiddleName_KeyPress);
            // 
            // Middle
            // 
            this.Middle.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Middle.Location = new System.Drawing.Point(359, 206);
            this.Middle.Name = "Middle";
            this.Middle.Size = new System.Drawing.Size(100, 23);
            this.Middle.TabIndex = 7;
            this.Middle.Text = " ";
            // 
            // SubmitButt
            // 
            this.SubmitButt.Location = new System.Drawing.Point(372, 399);
            this.SubmitButt.Name = "SubmitButt";
            this.SubmitButt.Size = new System.Drawing.Size(75, 23);
            this.SubmitButt.TabIndex = 6;
            this.SubmitButt.Text = "Submit";
            this.SubmitButt.UseVisualStyleBackColor = true;
            this.SubmitButt.Click += new System.EventHandler(this.SubmitButt_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(359, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "Middle Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(612, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Last Name";
            // 
            // label
            // 
            this.label.BackColor = System.Drawing.Color.LightGray;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(256, 42);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(305, 27);
            this.label.TabIndex = 12;
            this.label.Text = "Press \'Enter\' before moving on.";
            this.label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MiddleName);
            this.Controls.Add(this.Middle);
            this.Controls.Add(this.SubmitButt);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.Last);
            this.Controls.Add(this.First);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label First;
        private System.Windows.Forms.Label Last;
        private System.Windows.Forms.TextBox FirstName;
        private System.Windows.Forms.TextBox LastName;
        private System.Windows.Forms.TextBox MiddleName;
        private System.Windows.Forms.Label Middle;
        private System.Windows.Forms.Button SubmitButt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label;
    }
}

